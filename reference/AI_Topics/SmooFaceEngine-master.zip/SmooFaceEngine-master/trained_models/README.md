# WARNING
The file named tiny_XCEPTION.hdf5 is a trained model 
that could only be used for testing. Because this model 
was trained by only olivetti faces dataset, you know, this
dataset is too mini.
If you want to use this model in your production environment,
 you should train this model by more and more images.